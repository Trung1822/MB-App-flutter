﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using PCM_Backend.Models;
using PCM_Backend.Models.Enums;

namespace PCM_Backend.Data;

public class AppDbContext : IdentityDbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options)
        : base(options)
    {
    }

    public DbSet<Member> Members => Set<Member>();
    public DbSet<WalletTransaction> WalletTransactions => Set<WalletTransaction>();
    public DbSet<Court> Courts => Set<Court>();
    public DbSet<Booking> Bookings => Set<Booking>();

    // Thêm sau: Tournaments, Matches, Notifications, ...

    protected override void OnModelCreating(ModelBuilder builder)
    {
        base.OnModelCreating(builder);

        // Đặt tên bảng với prefix 692_
        builder.Entity<Member>().ToTable("692_Members");
        builder.Entity<WalletTransaction>().ToTable("692_WalletTransactions");
        builder.Entity<Court>().ToTable("692_Courts");
        builder.Entity<Booking>().ToTable("692_Bookings");

        // Precision cho decimal (MySQL cần rõ ràng)
        builder.Entity<Member>()
            .Property(m => m.WalletBalance).HasPrecision(18, 2);
        builder.Entity<Member>()
            .Property(m => m.TotalSpent).HasPrecision(18, 2);
        builder.Entity<Court>()
            .Property(c => c.PricePerHour).HasPrecision(18, 2);
        builder.Entity<Booking>()
            .Property(b => b.TotalPrice).HasPrecision(18, 2);
        builder.Entity<WalletTransaction>()
            .Property(t => t.Amount).HasPrecision(18, 2);

        // Enum lưu dạng string (dễ đọc, debug)
        builder.Entity<Member>()
            .Property(m => m.Tier).HasConversion<string>();
        builder.Entity<WalletTransaction>()
            .Property(t => t.Type).HasConversion<string>();
        builder.Entity<WalletTransaction>()
            .Property(t => t.Status).HasConversion<string>();
        builder.Entity<Booking>()
            .Property(b => b.Status).HasConversion<string>();

        // Index hỗ trợ check trùng lịch nhanh
        builder.Entity<Booking>()
            .HasIndex(b => new { b.CourtId, b.StartTime, b.EndTime })
            .IsUnique(false);   // không unique vì có thể nhiều booking khác court
    }
}