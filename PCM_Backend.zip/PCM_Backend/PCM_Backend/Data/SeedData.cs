﻿using Microsoft.AspNetCore.Identity;
using PCM_Backend.Data;
using PCM_Backend.Models;
using PCM_Backend.Models.Enums;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace PCM_Backend.Data;

public static class SeedData
{
    public static async Task SeedAsync(AppDbContext context, UserManager<IdentityUser> userManager, RoleManager<IdentityRole> roleManager)
    {
        if (context.Members.Any())
        {
            Console.WriteLine("Dữ liệu đã tồn tại → bỏ qua seeding.");
            return;
        }

        // 1. Tạo Roles
        string[] roles = { "Admin", "Treasurer", "Referee", "Member" };
        foreach (var role in roles)
        {
            if (!await roleManager.RoleExistsAsync(role))
                await roleManager.CreateAsync(new IdentityRole(role));
        }

        // 2. Admin (có cả Treasurer)
        var adminUser = await CreateUserIfNotExists(userManager, "admin@pcm.vn", "Admin@2026", new[] { "Admin", "Treasurer" });

        // 3. Treasurer riêng
        var treasurerUser = await CreateUserIfNotExists(userManager, "thuquy@pcm.vn", "ThuQuy@2026", new[] { "Treasurer" });

        // 4. Referee
        var refereeUser = await CreateUserIfNotExists(userManager, "trongtai@pcm.vn", "TrongTai@2026", new[] { "Referee" });

        // 5. Tạo 25 Members
        var random = new Random();
        var members = new List<Member>();

        for (int i = 1; i <= 25; i++)
        {
            var email = $"tv{i:00}@pcm.vn";
            var user = await CreateUserIfNotExists(userManager, email, "MatKhau@2026", new[] { "Member" });

            var member = new Member
            {
                UserId = user.Id,
                FullName = $"Thành viên {i:00}",
                JoinDate = DateTime.UtcNow.AddMonths(-random.Next(1, 36)),
                AvatarUrl = $"https://i.pravatar.cc/150?img={i}",
                WalletBalance = random.Next(200, 1001) * 10000m,        // 2.000.000 - 10.000.000
                TotalSpent = random.Next(0, 801) * 10000m,
                Tier = GetRandomTier(random),
                IsActive = true
            };
            members.Add(member);
        }
        context.Members.AddRange(members);
        await context.SaveChangesAsync();

        // 6. Tạo 6 sân
        var courts = new List<Court>
        {
            new Court { Name = "Sân 1", PricePerHour = 200000m, Description = "Sân tiêu chuẩn", IsActive = true },
            new Court { Name = "Sân 2", PricePerHour = 220000m, Description = "Sân có mái che", IsActive = true },
            new Court { Name = "Sân 3", PricePerHour = 200000m, Description = "Sân tiêu chuẩn", IsActive = true },
            new Court { Name = "Sân VIP 1", PricePerHour = 350000m, Description = "Sân cao cấp, đèn chiếu sáng", IsActive = true },
            new Court { Name = "Sân VIP 2", PricePerHour = 380000m, Description = "Sân VIP có điều hòa", IsActive = true },
            new Court { Name = "Sân Đôi", PricePerHour = 250000m, Description = "Sân dành cho đánh đôi", IsActive = true }
        };
        context.Courts.AddRange(courts);
        await context.SaveChangesAsync();

        // 7. Tạo một số giao dịch ví mẫu (cho 5 thành viên đầu)
        var first5Members = context.Members.Take(5).ToList();
        foreach (var member in first5Members)
        {
            context.WalletTransactions.AddRange(
                new WalletTransaction { MemberId = member.Id, Amount = 5000000m, Type = TransactionType.Deposit, Status = TransactionStatus.Completed, Description = "Nạp lần đầu", CreatedDate = DateTime.UtcNow.AddDays(-30) },
                new WalletTransaction { MemberId = member.Id, Amount = -800000m, Type = TransactionType.Payment, Status = TransactionStatus.Completed, Description = "Thanh toán đặt sân", CreatedDate = DateTime.UtcNow.AddDays(-15) },
                new WalletTransaction { MemberId = member.Id, Amount = 1200000m, Type = TransactionType.Reward, Status = TransactionStatus.Completed, Description = "Thưởng giải đấu", CreatedDate = DateTime.UtcNow.AddDays(-5) }
            );
        }
        await context.SaveChangesAsync();

        Console.WriteLine($"✅ Đã seed: 1 Admin, 1 Treasurer, 1 Referee, 25 Members, 6 Courts, một số giao dịch ví");
    }

    private static async Task<IdentityUser> CreateUserIfNotExists(UserManager<IdentityUser> userManager, string email, string password, string[] roles)
    {
        var user = await userManager.FindByEmailAsync(email);
        if (user == null)
        {
            user = new IdentityUser { UserName = email, Email = email, EmailConfirmed = true };
            await userManager.CreateAsync(user, password);
            await userManager.AddToRolesAsync(user, roles);
        }
        return user;
    }

    private static Tier GetRandomTier(Random random)
    {
        var values = Enum.GetValues(typeof(Tier));
        return (Tier)values.GetValue(random.Next(values.Length))!;
    }
}