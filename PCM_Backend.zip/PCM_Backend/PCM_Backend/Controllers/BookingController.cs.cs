﻿using System;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PCM_Backend.Data;
using PCM_Backend.Models;
using PCM_Backend.Models.Enums;

[Route("api/[controller]")]
[ApiController]
[Authorize(Roles = "Member")]  // chỉ thành viên mới đặt sân
public class BookingsController : ControllerBase
{
    private readonly AppDbContext _context;

    public BookingsController(AppDbContext context)
    {
        _context = context;
    }

    [HttpPost]
    public async Task<IActionResult> Create([FromBody] CreateBookingDto dto)
    {
        var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
        var member = await _context.Members.FirstOrDefaultAsync(m => m.UserId == userId);
        if (member == null) return Unauthorized("Không tìm thấy thành viên");

        var court = await _context.Courts.FindAsync(dto.CourtId);
        if (court == null) return NotFound("Sân không tồn tại");

        // Check trùng lịch
        var conflict = await _context.Bookings.AnyAsync(b =>
          b.CourtId == dto.CourtId &&
          b.Status != BookingStatus.Cancelled &&
          b.Status != BookingStatus.Completed &&
          ((b.StartTime < dto.EndTime && b.EndTime > dto.StartTime)));

        if (conflict) return BadRequest("Khung giờ đã bị đặt");

        var durationHours = (dto.EndTime - dto.StartTime).TotalHours;
        var totalPrice = (decimal)durationHours * court.PricePerHour;

        if (member.WalletBalance < totalPrice) return BadRequest("Số dư ví không đủ");

        var booking = new Booking
        {
            CourtId = dto.CourtId,
            MemberId = member.Id,
            StartTime = dto.StartTime,
            EndTime = dto.EndTime,
            TotalPrice = totalPrice,
            Status = BookingStatus.Holding,  // Giữ chỗ 5 phút
        };

        _context.Bookings.Add(booking);
        member.WalletBalance -= totalPrice;
        member.TotalSpent += totalPrice;

        await _context.SaveChangesAsync();

        return Ok(booking);
    }
}

public class CreateBookingDto
{
    public int CourtId { get; set; }
    public DateTime StartTime { get; set; }
    public DateTime EndTime { get; set; }
}