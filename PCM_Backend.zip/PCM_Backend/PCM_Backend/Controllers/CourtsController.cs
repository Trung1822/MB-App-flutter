﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PCM_Backend.Data;
using PCM_Backend.Models;

namespace PCM_Backend.Controllers;

[Route("api/[controller]")]
[ApiController]
public class CourtsController : ControllerBase
{
    private readonly AppDbContext _context;

    public CourtsController(AppDbContext context)
    {
        _context = context;
    }

    /// <summary>
    /// Lấy danh sách tất cả sân đang hoạt động
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> GetAll()
    {
        var courts = await _context.Courts
            .Where(c => c.IsActive)
            .Select(c => new
            {
                id = c.Id,
                name = c.Name,
                description = c.Description,
                pricePerHour = c.PricePerHour
            })
            .OrderBy(c => c.name)
            .ToListAsync();

        return Ok(courts);
    }

    /// <summary>
    /// Lấy chi tiết một sân theo ID
    /// </summary>
    [HttpGet("{id}")]
    public async Task<IActionResult> GetById(int id)
    {
        var court = await _context.Courts
            .FirstOrDefaultAsync(c => c.Id == id && c.IsActive);

        if (court == null) return NotFound();

        return Ok(new
        {
            id = court.Id,
            name = court.Name,
            description = court.Description,
            pricePerHour = court.PricePerHour
        });
    }
}