﻿using System.ComponentModel.DataAnnotations;
using System.Security.Claims;
using System.Text.Json.Serialization;
using Microsoft.AspNetCore.Authorization;          // thêm nếu cần [Authorize]
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;               // cần cho FirstOrDefaultAsync
using PCM_Backend.Data;                            // AppDbContext
using PCM_Backend.Services;                        // TokenService

namespace PCM_Backend.Controllers;

[Route("api/[controller]")]
[ApiController]
public class AuthController : ControllerBase
{
    private readonly UserManager<IdentityUser> _userManager;
    private readonly SignInManager<IdentityUser> _signInManager;
    private readonly TokenService _tokenService;
    private readonly AppDbContext _context;           // ← thêm dòng này

    public AuthController(
        UserManager<IdentityUser> userManager,
        SignInManager<IdentityUser> signInManager,
        TokenService tokenService,
        AppDbContext context)                         // ← thêm parameter này
    {
        _userManager = userManager;
        _signInManager = signInManager;
        _tokenService = tokenService;
        _context = context;                           // ← gán giá trị
    }

    public class LoginDto
    {
        [Required]
        [JsonPropertyName("email")]  // ← chấp nhận key "email" từ JSON
        public string Email { get; set; } = string.Empty;

        [Required]
        [JsonPropertyName("password")]
        public string Password { get; set; } = string.Empty;
    }

    [HttpPost("login")]
    public async Task<IActionResult> Login([FromBody] LoginDto dto)
    {
        var user = await _userManager.FindByEmailAsync(dto.Email);
        if (user == null) return Unauthorized(new { message = "Email không tồn tại" });

        var result = await _signInManager.CheckPasswordSignInAsync(user, dto.Password, lockoutOnFailure: false);
        if (!result.Succeeded) return Unauthorized(new { message = "Mật khẩu sai" });

        var roles = await _userManager.GetRolesAsync(user);
        var token = _tokenService.GenerateToken(user, roles);

        return Ok(new
        {
            token,
            user = new
            {
                id = user.Id,
                email = user.Email,
                roles
            }
        });
    }

    [HttpGet("me")]
    [Authorize]  // ← thêm để bảo vệ route này (chỉ user đã login mới gọi được)
    public async Task<IActionResult> GetCurrentUser()
    {
        var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
        if (string.IsNullOrEmpty(userId)) return Unauthorized();

        var user = await _userManager.FindByIdAsync(userId);
        if (user == null) return NotFound("Không tìm thấy user");

        var member = await _context.Members
            .FirstOrDefaultAsync(m => m.UserId == userId);

        var roles = await _userManager.GetRolesAsync(user);

        return Ok(new
        {
            id = user.Id,
            email = user.Email,
            fullName = member?.FullName ?? "Chưa cập nhật",
            walletBalance = member?.WalletBalance ?? 0,
            tier = member?.Tier.ToString() ?? "Standard",
            roles
        });
    }
}