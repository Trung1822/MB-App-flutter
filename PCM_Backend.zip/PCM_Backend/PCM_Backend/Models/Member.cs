﻿// Models/Member.cs
using Microsoft.AspNetCore.Identity;
using PCM_Backend.Models.Enums;

namespace PCM_Backend.Models;

public class Member
{
    public int Id { get; set; }
    public string FullName { get; set; } = string.Empty;
    public DateTime JoinDate { get; set; } = DateTime.UtcNow;
    public string? AvatarUrl { get; set; }
    public decimal WalletBalance { get; set; }
    public decimal TotalSpent { get; set; }
    public Tier Tier { get; set; } = Tier.Standard;
    public bool IsActive { get; set; } = true;

    // Liên kết Identity
    public string UserId { get; set; } = null!;
    public IdentityUser User { get; set; } = null!;

    // Navigation properties (tùy chọn, giúp query dễ hơn)
    public ICollection<WalletTransaction> Transactions { get; set; } = new List<WalletTransaction>();
    public ICollection<Booking> Bookings { get; set; } = new List<Booking>();
}