﻿// Models/Booking.cs
using PCM_Backend.Models.Enums;

namespace PCM_Backend.Models;

public class Booking
{
    public int Id { get; set; }
    public int CourtId { get; set; }
    public Court Court { get; set; } = null!;
    public int MemberId { get; set; }
    public Member Member { get; set; } = null!;

    public DateTime StartTime { get; set; }
    public DateTime EndTime { get; set; }
    public decimal TotalPrice { get; set; }
    public int? TransactionId { get; set; }     // Liên kết trừ tiền ví

    public bool IsRecurring { get; set; }
    public string? RecurrenceRule { get; set; } // ví dụ: "FREQ=WEEKLY;BYDAY=TU,TH"
    public int? ParentBookingId { get; set; }   // nếu là booking con của recurring

    public BookingStatus Status { get; set; } = BookingStatus.Holding;
}