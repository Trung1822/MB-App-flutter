﻿// Models/WalletTransaction.cs
using PCM_Backend.Models.Enums;

namespace PCM_Backend.Models;

public class WalletTransaction
{
    public int Id { get; set; }
    public int MemberId { get; set; }
    public Member Member { get; set; } = null!;

    public decimal Amount { get; set; }
    public TransactionType Type { get; set; }
    public TransactionStatus Status { get; set; } = TransactionStatus.Pending;
    public string? RelatedId { get; set; }      // "booking:123" hoặc "tournament:456"
    public string? Description { get; set; }
    public DateTime CreatedDate { get; set; } = DateTime.UtcNow;
}