﻿// Models/Enums.cs
namespace PCM_Backend.Models.Enums;

public enum Tier { Standard, Silver, Gold, Diamond }

public enum TransactionType { Deposit, Withdraw, Payment, Refund, Reward }

public enum TransactionStatus { Pending, Completed, Rejected, Failed }

public enum BookingStatus { Holding, PendingPayment, Confirmed, Cancelled, Completed }

public enum TournamentFormat { RoundRobin, Knockout, Hybrid }

public enum TournamentStatus { Open, Registering, DrawCompleted, Ongoing, Finished }

public enum MatchStatus { Scheduled, InProgress, Finished }

public enum NotificationType { Info, Success, Warning, Error }