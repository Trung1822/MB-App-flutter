﻿// Models/Court.cs
namespace PCM_Backend.Models;

public class Court
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;    // "Sân 1", "Sân VIP"
    public bool IsActive { get; set; } = true;
    public string? Description { get; set; }
    public decimal PricePerHour { get; set; }

    public ICollection<Booking> Bookings { get; set; } = new List<Booking>();
}