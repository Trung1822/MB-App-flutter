package com.example.pickleball

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
