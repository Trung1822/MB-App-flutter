import 'package:flutter/material.dart';

class TournamentListScreen extends StatelessWidget {
  const TournamentListScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final tournaments = [
      {'name': 'Summer Open 2026', 'status': 'Finished', 'fee': 200000},
      {'name': 'Winter Cup', 'status': 'Registering', 'fee': 300000},
    ];

    return ListView.builder(
      itemCount: tournaments.length,
      itemBuilder: (context, index) {
        final t = tournaments[index];
        return Card(
          margin: const EdgeInsets.all(12),
          child: ListTile(
            leading: const Icon(Icons.emoji_events),
            title: Text(t['name'] as String),
            subtitle: Text('Trạng thái: ${t['status']} – Phí: ${t['fee']}đ'),
            trailing: t['status'] == 'Registering'
                ? ElevatedButton(
                    onPressed: () {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text('Đăng ký giải thành công (mock)'),
                        ),
                      );
                    },
                    child: const Text('Tham gia'),
                  )
                : const Text('Đã kết thúc'),
          ),
        );
      },
    );
  }
}
