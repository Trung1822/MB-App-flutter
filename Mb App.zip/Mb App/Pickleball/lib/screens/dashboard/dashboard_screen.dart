import 'package:flutter/material.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _header(),
          const SizedBox(height: 20),
          _statisticGrid(),
          const SizedBox(height: 24),
          _todayBooking(),
        ],
      ),
    );
  }

  Widget _header() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: const [
        Text('Xin chào 👋', style: TextStyle(fontSize: 18)),
        SizedBox(height: 4),
        Text(
          'PCM Pickleball Dashboard',
          style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
        ),
      ],
    );
  }

  Widget _statisticGrid() {
    return GridView.count(
      crossAxisCount: 2,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      crossAxisSpacing: 12,
      mainAxisSpacing: 12,
      children: const [
        _StatCard(title: 'Sân trống', value: '4'),
        _StatCard(title: 'Đã đặt hôm nay', value: '12'),
        _StatCard(title: 'Doanh thu', value: '2.500.000đ'),
        _StatCard(title: 'Giải đấu', value: '3'),
      ],
    );
  }

  Widget _todayBooking() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Lịch đặt hôm nay',
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 12),
        _bookingItem('Sân 1', '08:00 - 09:00', 'Nguyễn Văn A'),
        _bookingItem('Sân 2', '09:00 - 10:00', 'Trần Thị B'),
        _bookingItem('Sân 3', '10:00 - 11:00', 'Lê Văn C'),
      ],
    );
  }

  Widget _bookingItem(String court, String time, String user) {
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: ListTile(
        leading: const Icon(Icons.sports_tennis),
        title: Text(court),
        subtitle: Text('$time • $user'),
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  final String title;
  final String value;

  const _StatCard({required this.title, required this.value});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              value,
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            Text(title),
          ],
        ),
      ),
    );
  }
}
