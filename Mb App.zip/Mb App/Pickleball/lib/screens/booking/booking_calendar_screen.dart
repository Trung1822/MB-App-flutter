import 'package:flutter/material.dart';
import 'package:table_calendar/table_calendar.dart';

class BookingCalendarScreen extends StatefulWidget {
  const BookingCalendarScreen({super.key});

  @override
  State<BookingCalendarScreen> createState() => _BookingCalendarScreenState();
}

class _BookingCalendarScreenState extends State<BookingCalendarScreen> {
  DateTime focusedDay = DateTime.now();
  DateTime selectedDay = DateTime.now();

  /// Mock slot đã đặt
  final Map<DateTime, List<String>> bookedSlots = {
    DateTime.now(): ['08:00', '09:00'],
  };

  @override
  Widget build(BuildContext context) {
    final slots = [
      '06:00',
      '07:00',
      '08:00',
      '09:00',
      '10:00',
      '11:00',
      '16:00',
      '17:00',
      '18:00',
    ];

    return Column(
      children: [
        TableCalendar(
          firstDay: DateTime.utc(2020),
          lastDay: DateTime.utc(2030),
          focusedDay: focusedDay,
          selectedDayPredicate: (day) => isSameDay(day, selectedDay),
          onDaySelected: (selected, focused) {
            setState(() {
              selectedDay = selected;
              focusedDay = focused;
            });
          },
        ),
        const SizedBox(height: 8),

        Expanded(
          child: ListView(
            children: slots.map((slot) {
              final isBooked =
                  bookedSlots[selectedDay]?.contains(slot) ?? false;

              return ListTile(
                leading: Icon(
                  Icons.sports_tennis,
                  color: isBooked ? Colors.red : Colors.green,
                ),
                title: Text('Khung giờ $slot'),
                trailing: isBooked
                    ? const Text('Đã đặt', style: TextStyle(color: Colors.red))
                    : const Text(
                        'Trống',
                        style: TextStyle(color: Colors.green),
                      ),
                onTap: isBooked ? null : () => _showBookingSheet(context, slot),
              );
            }).toList(),
          ),
        ),
      ],
    );
  }

  void _showBookingSheet(BuildContext context, String slot) {
    showModalBottomSheet(
      context: context,
      builder: (_) => Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'Xác nhận đặt sân',
              style: Theme.of(context).textTheme.titleLarge,
            ),
            const SizedBox(height: 12),
            Text(
              'Ngày: ${selectedDay.day}/${selectedDay.month}/${selectedDay.year}',
            ),
            Text('Giờ: $slot'),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: () {
                setState(() {
                  bookedSlots.putIfAbsent(selectedDay, () => []);
                  bookedSlots[selectedDay]!.add(slot);
                });
                Navigator.pop(context);
              },
              child: const Text('Đặt sân'),
            ),
          ],
        ),
      ),
    );
  }
}
