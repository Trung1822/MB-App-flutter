import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class WalletScreen extends StatelessWidget {
  const WalletScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final balance = 2500000;

    final transactions = [
      {'type': 'Deposit', 'amount': 1000000, 'date': '20/01/2026'},
      {'type': 'Booking', 'amount': -200000, 'date': '22/01/2026'},
      {'type': 'Tournament Fee', 'amount': -300000, 'date': '25/01/2026'},
    ];

    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // SỐ DƯ
          Card(
            color: Colors.green.shade600,
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Số dư ví', style: TextStyle(color: Colors.white)),
                  const SizedBox(height: 8),
                  Text(
                    NumberFormat.currency(
                      locale: 'vi_VN',
                      symbol: '₫',
                    ).format(balance),
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),
          ),

          const SizedBox(height: 16),

          // NẠP TIỀN
          ElevatedButton.icon(
            onPressed: () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Gửi yêu cầu nạp tiền (mock)')),
              );
            },
            icon: const Icon(Icons.add),
            label: const Text('Nạp tiền'),
          ),

          const SizedBox(height: 16),
          const Text(
            'Lịch sử giao dịch',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),

          const SizedBox(height: 8),

          Expanded(
            child: ListView.builder(
              itemCount: transactions.length,
              itemBuilder: (context, index) {
                final t = transactions[index];
                final isPlus = (t['amount'] as int) > 0;

                return ListTile(
                  leading: Icon(
                    isPlus ? Icons.arrow_downward : Icons.arrow_upward,
                    color: isPlus ? Colors.green : Colors.red,
                  ),
                  title: Text(t['type'] as String),
                  subtitle: Text(t['date'] as String),
                  trailing: Text(
                    '${t['amount']} đ',
                    style: TextStyle(
                      color: isPlus ? Colors.green : Colors.red,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
